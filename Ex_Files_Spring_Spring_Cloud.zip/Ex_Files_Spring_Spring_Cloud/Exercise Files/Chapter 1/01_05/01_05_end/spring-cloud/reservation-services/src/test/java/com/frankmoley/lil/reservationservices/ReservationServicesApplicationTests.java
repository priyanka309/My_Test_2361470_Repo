package com.frankmoley.lil.reservationservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationServicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
