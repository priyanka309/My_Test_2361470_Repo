package com.example.guestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuestserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
