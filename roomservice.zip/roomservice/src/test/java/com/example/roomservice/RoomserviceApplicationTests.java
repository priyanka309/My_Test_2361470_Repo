package com.example.roomservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
