package com.example.reservationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
